<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('case_studies', function (Blueprint $table) {
            $table->string('short_description', 255)->nullable()->after('summary');
            $table->string('duration', 100)->nullable()->after('short_description');
            $table->string('year', 4)->nullable()->after('duration');
            $table->text('challenge_overview')->nullable()->after('challenge');
            $table->json('challenge_points')->nullable()->after('challenge_overview');
            $table->text('solution_overview')->nullable()->after('solution');
            $table->json('solution_points')->nullable()->after('solution_overview');
            $table->json('results_data')->nullable()->after('results');
            $table->json('process_steps')->nullable()->after('results_data');
            $table->text('testimonial_quote')->nullable()->after('technologies');
            $table->string('testimonial_author', 255)->nullable()->after('testimonial_quote');
            $table->string('testimonial_role', 255)->nullable()->after('testimonial_author');
            $table->json('gallery')->nullable()->after('testimonial_role');
            $table->string('meta_title', 255)->nullable()->after('gallery');
            $table->text('meta_description')->nullable()->after('meta_title');
            $table->string('highlight_stat_value', 50)->nullable()->after('meta_description');
            $table->string('highlight_stat_label', 100)->nullable()->after('highlight_stat_value');
        });
    }

    public function down(): void
    {
        Schema::table('case_studies', function (Blueprint $table) {
            $table->dropColumn([
                'short_description', 'duration', 'year', 'challenge_overview', 'challenge_points',
                'solution_overview', 'solution_points', 'results_data', 'process_steps',
                'testimonial_quote', 'testimonial_author', 'testimonial_role', 'gallery',
                'meta_title', 'meta_description', 'highlight_stat_value', 'highlight_stat_label'
            ]);
        });
    }
};
