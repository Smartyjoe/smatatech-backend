<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('services', function (Blueprint $table) {
            $table->json('features')->nullable()->after('full_description');
            $table->json('benefits')->nullable()->after('features');
            $table->json('process_steps')->nullable()->after('benefits');
            $table->string('meta_title', 255)->nullable()->after('order');
            $table->text('meta_description')->nullable()->after('meta_title');
            $table->string('og_image', 500)->nullable()->after('meta_description');
        });
    }

    public function down(): void
    {
        Schema::table('services', function (Blueprint $table) {
            $table->dropColumn(['features', 'benefits', 'process_steps', 'meta_title', 'meta_description', 'og_image']);
        });
    }
};
