<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('posts', function (Blueprint $table) {
            $table->string('read_time', 50)->nullable()->after('content');
            $table->boolean('is_featured')->default(false)->after('read_time');
            $table->json('tags')->nullable()->after('is_featured');
            $table->boolean('comments_enabled')->default(true)->after('tags');
            $table->string('og_image', 500)->nullable()->after('meta_description');
        });
    }

    public function down(): void
    {
        Schema::table('posts', function (Blueprint $table) {
            $table->dropColumn(['read_time', 'is_featured', 'tags', 'comments_enabled', 'og_image']);
        });
    }
};
